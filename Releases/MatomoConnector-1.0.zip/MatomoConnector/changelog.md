# Changelog


## v1.0

### What's Changed

_(most recent changes are listed on top):_
- Initial release
- Added Tracking Code
- Added Image Tracking Code
- Added JS Fallback Code
- Added `en_GB` translations


Read the full [**Changelog**](../master/changelog.md "See changes") or view the [**README**](../master/README.md "View README")
