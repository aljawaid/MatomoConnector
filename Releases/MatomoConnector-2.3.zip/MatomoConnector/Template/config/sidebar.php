<li <?= $this->app->checkMenuSelection('MatomoConnectorController', 'show', 'MatomoConnector') ?>>
    <?= $this->url->link('MatomoConnector', 'MatomoConnectorController', 'show', ['plugin' => 'MatomoConnector']) ?>
</li>
